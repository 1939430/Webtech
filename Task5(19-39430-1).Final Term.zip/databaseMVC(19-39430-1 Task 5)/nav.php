 <ul>
        <li><a href="addStudent.php"> Add student</a></li>
        <li><a href="showAllStudents.php"> Show all students</a></li>
        <li><a href="searchUser.php"> Search Students</a></li>
    </ul>