
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Document</title>
</head>
<body>
    <fieldset>
        <h2 align="center">University Management </h2>
    </fieldset>

</body>
</html>