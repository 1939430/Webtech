<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Document</title>
</head>
<body>
	<fieldset>
		<h4  align="center" >Copyright© All Rights Reserved.</h4>
		<h4 align="center">Thank You</h4>
	</fieldset>
	


</body>
</html>