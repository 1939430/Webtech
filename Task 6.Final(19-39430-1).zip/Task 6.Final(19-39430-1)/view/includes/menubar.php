<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Document</title>
</head>
<body>
	<a href="home.php">Home</a> <br><br>
	<a href="profile.php">Profile</a><br><br>
	<a href="user.php">View User's</a><br><br>
	<a href="addEmployee.php">Add Employee</a><br><br>
	<a href="showEmployee.php">Show Employee</a><br><br>
	<a href="logout.php">Log out</a><br><br>


</body>
</html>