<!DOCTYPE html>
<html>
<body>

<h1>The fieldset element</h1>

<form action="/action_page.php">
 <fieldset>
  <legend>Name:</legend>
  <label for="name">Name:</label>
  <input type="text" id="name" name="name"><br><br>
 
 </fieldset>
 
  <fieldset>
   <label for="email">Email:</label>
  <input type="email" id="email" name="email"><br><br>
   </fieldset>
   
  <fieldset>
    <label for="birthday">Birthday:</label>
  <input type="date" id="birthday" name="birthday"><br><br>
    </fieldset>

 <fieldset>
<p>Please select your Gender:</p>
  <input type="radio" id="Male" name="Gender" value="male">
  <label for="male">Male</label>
  <input type="radio" id="Female" name="Gender" value="female">
  <label for="female">Female</label>
  <input type="radio" id="Others" name="Gender" value="others">
  <label for="others">Others</label>

  <br>  
 </fieldset>
<fieldset>
<p>DEGREE</p>
<input type="checkbox" id="degree" name="degree" value="SSC">
  <label for="degree">SSC</label>
  <input type="checkbox" id="degree" name="degree" value="HSC">
  <label for="degree">HSC</label>
  <input type="checkbox" id="degree" name="degree" value="BSC">
  <label for="degree">BSC</label>
  <input type="checkbox" id="degree" name="degree" value="MSC">
  <label for="degree">MSC</label>
</fieldset>

<fieldset>
<p>Blood Group</p>
 <label for="Blood">Blood Group:</label>
  <select name="Blood" id="Blood">
    <option value="O+">O+</option>
    <option value="O-">O-</option>
    <option value="A+">A+</option>
<option value="AB+">AB+</option>
    <option value="B+">B+</option>
  </select>
 </fieldset>
 <input type="submit" value="Submit">

</form>
  
</body>
</html>
