<?php 
 
session_start();
 
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Report_Issue</title>
</head>
<body>
	<p class="lead text-center" style="margin: 10px;"><a href="index.php">Back</a>
	
	<p style= "text-align:center;">Report Issue</p>

	<table border="0" width="100%">
	<tr>
          <td width="5px"><img src="image/Report.png" alt=""></td>
            <td width="5px"> </td>
            
        </tr>		

	</table>

</body>
</html>