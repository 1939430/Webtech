<!DOCTYPE html>
<html>
<head><title>Curriculum Vitae</title></head>
<body>

<h2>Curriculum Vitae</h2>
<img src="https://easydrawingart.com/wp-content/uploads/2019/08/How-to-draw-a-boy.jpg" alt="Easydrawingart" width="500" height="333">

  <label for="name"> Name:</label<br>
  <input type="text" id="name" name="name" value="John"><br><br>

  <label for="fname">Fathers Name:</label<br>
  <input type="text" id="name" name="name" value="Don"><br><br>

  <label for="mname">Mothers Name:</label<br>
  <input type="text" id="name" name="name" value="Manila"><br><br>

  Gender <input type="radio" name="gender" id="male"> <label for="male">Male</label>
	<input type="radio" name="gender" id="female">  <label for="female">Female</label><br><br>

  <label for="dob">Date of Birth </label>
	<input type="Date" name="dob" id="dob"><br><br>
  <label for="religion">Religion </label>
	<select id="religion">

		<option value="muslim">Muslim</option>
		<option value="hindu">Hindu</option>
		<option value="cristian">Cristian</option>
		<option value="buddha">Buddha</option>
		
	</select>
  <label for="praddress">Present Address:</label><br>
  <input type="text" id="praddress" name="praddress" value="New York"><br><br>
  <label for="peaddress">Permanent Address:</label><br>
  <input type="text" id="peaddress" name="peaddress" value="Washington"><br><br>
  <label for="phone">Phone:</label><br>
  <input type="text" id="phone" name="phone" value="01709095383"><br><br>
  <label for="email">Email:</label><br>
  <input type="text" id="email" name="email" value="john@aiub.edu"><br><br>
  <label for="hobby">Hobby:</label><br>
  <input type="text" id="hobby" name="hobby" value="travelling"><br><br>
  <label for="equalification">Educational Qualification:</label><br>
  <input type="text"id="equalification"name="equalification"value="B.Sc"><br><br>

</body>
</html>