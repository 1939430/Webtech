<!DOCTYPE html>
<html>
<head><title>Information Form</title></head>
<body>

<h2 style="color:red;">Donor Information</h2>

<form action="/action_page.php">
  <label for="fname">First name:</label<br>
  <input type="text" id="fname" name="fname" value="John"><br><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="lname" value="Doe"><br><br>
    <label for="company">Company:</label><br>
  <input type="text" id="company" name="company" value="IT"><br><br>
  <label for="address1">Address1:</label><br>
  <input type="text" id="address1" name="address1" value="AIUB"><br><br>
  <label for="address2">Address2:</label><br>
  <input type="text" id="address2" name="address2" value="Campus"><br><br>
  <label for="city">City:</label><br>
  <input type="text" id="city" name="city" value="Dhaka"><br><br>
  <label for="state">State </label>
  
	<select id="state">

		<option value="Paltan">Paltan</option>
		<option value="Kuril">Kuril</option>
		<option value="Badda">Badda</option>
		<option value="Basundhara">Basundhara</option>
		
	</select>

  <label for="zip code">Zip code:</label><br>
  <input type="text" id="zip code" name="zip code" value="1203"><br><br>
  <label for="country">Country </label>
  
	<select id="country">

		<option value="Bangladesh">Bangladesh</option>
		<option value="India">India</option>
		<option value="England">England</option>
		<option value="Canada">Canada</option>
		
	</select>


  <label for="phone">Phone:</label><br>
  <input type="text" id="phone" name="phone" value="01709095383"><br><br>
  <label for="fax">Fax:</label><br>
  <input type="text" id="fax" name="fax" value="0088-2-934700"><br><br>
  <label for="email">Email:</label><br>
  <input type="text" id="email" name="email" value="john@aiub.edu"><br><br>
  
	Donation Amount <input type="radio" name="donation amount" id="none"> <label for="none">None</label>
	<input type="radio" name="donation amount" id="$50">  <label for="$50">$50</label>
    <input type="radio" name="donation amount" id="$75">  <label for="$75">$75</label>
    <input type="radio" name="donation amount" id="$100">  <label for="$100">$100</label>
    <input type="radio" name="donation amount" id="$250">  <label for="$250">$250</label>
    <input type="radio" name="donation amount" id="other">  <label for="other">Other</label>
    <br><br>
    <label for="other amount">Other Amount:</label><br>
  <input type="text" id="other amount" name="other amount" value="$350"><br><br>
  Recurring Donation
    <input type="checkbox" name="recuring donation" id="I am interested in giving on a regular basis"> <label for="I am interested in giving on a regular basis">I am interested in giving on a regular basis</label>
	<br><br>
    <label for="monthly credit card $">Monthly Credit Card$:</label><br>
  <input type="text" id="monthly credit card $" name="monthly credit card $" value="$1000"><br><br>
  <label for="months">Months:</label><br>
  <input type="text" id="months" name="months" value="12"><br><br>
  

 
 


<h2 style="color:red;">Honorarium and Memorial Donation Information</h2>

<form action="/action_page.php">
I would like to make this donation <input type="radio" name="I would like to make this donation" id="to honor"> <label for="to honor">To Honor</label>
	<input type="radio" name="I would like to make this donation" id="in memory of">  <label for="in memory of">In Memory Of</label>
  <br><br>
  <label for="name"> name:</label<br>
  <input type="text" id="name" name="name" value="John"><br><br>
  <label for="acknowledge donation to">Acknowledge Donation To:</label<br>
  <input type="text" id="acknowledge donation to" name="ackowledge donation to" value="Fund"><br><br>
  <label for="address">Address:</label><br>
  <input type="text" id="address" name="address" value="AIUB"><br><br>
  <label for="city">City:</label><br>
  <input type="text" id="city" name="city" value="Dhaka"><br><br>
  <label for="state">State </label>
  
	<select id="state">

		<option value="Paltan">Paltan</option>
		<option value="Kuril">Kuril</option>
		<option value="Badda">Badda</option>
		<option value="Basundhara">Basundhara</option>
		
	</select>
    <label for="zip">Zip:</label><br>
  <input type="text" id="zip" name="zip" value="1203"><br><br>
  <h2 style="color:red;">Additional Information</h2>
  
  <form action="/action_page.php">
  <h2>Please enter your name,company or organization you would like to prefer</h2> 
<label for="name"> name:</label<br>
  <input type="text" id="name" name="name" value="John"><br><br>
  <input type="checkbox" id="I would like my gift to remain anonymous"> <label for="I would like my gift to remain anonymous">I would like my gift to remain anonymous</label>
  <input type="checkbox" id="My employers offer a matching gift program.I will mail the matching gift form"> <label for="My employers offer a matching gift program.I will mail the matching gift form">My employers offer a matching gift program.I will mail the matching gift form</label>
  <input type="checkbox" id="Please save the cost of acknowledging this gift by not mailing a thank you letter"> <label for="Please save the cost of acknowledging this gift by not mailing a thank you letter">Please save the cost of acknowledging this gift by not mailing a thank you letter</label>
  
  
	<br><br>
    <label for="comments">Comments:</label><br>
  <input type="text" id="comments" name="comments" value="good"><br><br> 
    How may we contact you?
    <input type="checkbox" name=" How may we contact you?" id="E-mail"> <label for="E-mail">E-mail</label>
    <input type="checkbox" name=" How may we contact you?" id="Poster Mail"> <label for="Poster Mail">Poster Mail</label>
    <input type="checkbox" name=" How may we contact you?" id="Telephone"> <label for="Telephone">Telephone</label>
    <input type="checkbox" name=" How may we contact you?" id="Fax"> <label for="Fax">Fax</label>
	<br><br>
    I would like to receive newsletters and information about special events by:
    <input type="checkbox" name="I would like to receive newsletters and information about special events by: " id="E-mail"> <label for="E-mail">E-mail</label>
    <input type="checkbox" name="I would like to receive newsletters and information about special events by: " id="Poster Mail"> <label for="Poster Mail">Poster Mail</label>
    <input type="checkbox" name="I would like to receive newsletters and information about special events by: " id="I would like information about volunteering"> <label for="I would like information about volunteering">I would like information about volunteering</label>
    
	<br><br>
    <input type="reset" value="Reset">
    <input type="continue" value="Continue">




 
</form>




</body>
</html>